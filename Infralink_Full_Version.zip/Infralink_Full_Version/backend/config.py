db_config = {
    "host": "localhost",
    "user": "root",
    "password": "office123",  # change to your local MySQL password
    "database": "infralink_db"
}


